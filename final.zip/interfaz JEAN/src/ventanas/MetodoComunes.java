/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanas;

import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author usuario
 */
public class MetodoComunes {

    String DatetoString(Date dt_fecha) 
    {
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
        String st_fecha= formato.format(dt_fecha);
      return st_fecha;
    }
    
    /*Metodo permite controlar que solo se ingrese texto en los textbox. Se debe inicializar en el init de los formularios*/
     void SoloLetras(JTextField a) {
        a.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                char c = ke.getKeyChar();
                if (Character.isDigit(c)) {
                    ///getToolKit().beep();
                    Toolkit.getDefaultToolkit().beep();
                    //metodo consume() hace que ese tecleo no sirva 
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE LETRAS");

                    //no tomo encuenta caracteres especiales por evitar conflictos en la BDD
                } else if ((int) ke.getKeyChar() > 32 && (int) ke.getKeyChar() <= 47
                        || (int) ke.getKeyChar() >= 58 && (int) ke.getKeyChar() <= 64
                        || (int) ke.getKeyChar() >= 91 && (int) ke.getKeyChar() <= 96
                        || (int) ke.getKeyChar() >= 123 && (int) ke.getKeyChar() <= 163
                        || (int) ke.getKeyChar() >= 166 && (int) ke.getKeyChar() <= 208) {

                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE LETRAS!");
                }
            }

            // estos dos metodos sobreescriben lo de la calse padre para mejorarla 
            @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }
     
     
     /*Metodo permite controlar que solo se ingrese texto en los A. Se debe inicializar en el init de los formularios*/
     void SoloLetrasArea(JTextArea a) {
        a.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                char c = ke.getKeyChar();
                if (Character.isDigit(c)) {
                    ///getToolKit().beep();
                    Toolkit.getDefaultToolkit().beep();
                    //metodo consume() hace que ese tecleo no sirva
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE LETRAS");

                    //no tomo encuenta caracteres especiales por evitar conflictos en la BDD
                } else if ((int) ke.getKeyChar() > 32 && (int) ke.getKeyChar() <= 47
                        || (int) ke.getKeyChar() >= 58 && (int) ke.getKeyChar() <= 64
                        || (int) ke.getKeyChar() >= 91 && (int) ke.getKeyChar() <= 96
                        || (int) ke.getKeyChar() >= 123 && (int) ke.getKeyChar() <= 225) {

                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE LETRAS!");
                }
            }

            // estos dos metodos sobreescriben lo de la calse padre para mejorarla 
            @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }
 /*Metodo permite controlar que solo se ingrese numeros en los textbox. Se debe inicializar en el init de los formularios*/

      void SoloNumeros(JTextField a) {
        a.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                char c = ke.getKeyChar();
                if (Character.isLetter(c)) {
                    ///getToolKit().beep();
                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE NUMEROS!");

                } else if ((int) ke.getKeyChar() > 32 && (int) ke.getKeyChar() <= 37
                        || (int) ke.getKeyChar() >= 58 && (int) ke.getKeyChar() <= 64
                        || (int) ke.getKeyChar() >= 91 && (int) ke.getKeyChar() <= 96
                        || (int) ke.getKeyChar() >= 123 && (int) ke.getKeyChar() <= 225) {

                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();
                    JOptionPane.showMessageDialog(null, "INGRESE NUMEROS");
                }
            }

            // estos dos metodos sobreescriben lo de la calse padre para mejorarla 
            @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }
    /*Metodo permite controlar el limite de caractares que se debe ingresar solo se ingrese texto en los textbox. Se debe inicializar en el init de los formularios*/

    public void LimitaCaracteres(JTextField a, int lim) {
        a.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
                char c = ke.getKeyChar();
                if (a.getText().length() == lim) {
                    ///getToolKit().beep();
                    Toolkit.getDefaultToolkit().beep();
                    ke.consume();

                }
            }

            @Override
            public void keyPressed(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });
    }
// Metodo para copiar archivos del un destino a la carpeta de images cosmetologica
 public  void copiarArchivos(File source, File dest) throws IOException {
    InputStream is = null;
    OutputStream os = null;
    try {
        is = new FileInputStream(source);
        os = new FileOutputStream(dest);
        byte[] buffer = new byte[1024];
        int length;
        while ((length = is.read(buffer)) > 0) {
            os.write(buffer, 0, length);
        }
        } finally {
        is.close();
        os.close();
    }
}
 // Metodo para extraer la extension
 public String getFileExtension(File file) {
    String name = file.getName();
    try {
        return name.substring(name.lastIndexOf(".") + 1);
    } catch (Exception e) {
        return "";
    }
}

    
}
